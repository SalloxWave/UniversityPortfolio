"is" "=="
"less than" "<"
"greater than" ">"
"starts with" ".start_with?"