//
// Created by alexanderlinux on 12/9/16.
//

#ifndef GAME38_GAME_H
#define GAME38_GAME_H

#include <SFML/Window/Event.hpp>
#include <SFML/System/Time.hpp>
#include <SFML/System/Sleep.hpp>

#include "level.h"
#include "player.h"
#include "projectile.h"
#include "enum_action.h"
#include "enum_player_state.h"
#include "enum_projectile_state.h"
#include "struct_point.h"

#include "main_menu.h"
#include "characterwindow.h"
#include "gameboard.h"
#include "enum_window_state.h"
#include "enum_winning_option.h"

class Game
{
public:
    Game() = default;
    void run();
private:
    void run_main_menu();
    void run_character_screen();
    void run_gameboard();
    //How to initialize again
    //main_menu = Main_Menu(values)
    //Do we want to init windows here or locally in "run" functions
    //The same question about players and level
    int player1_selected_id;
    int player2_selected_id;
    Window_State window_state { Window_State::MainMenu };
    sf::Event event;
    sf::Keyboard::Key key_code { sf::Keyboard::Unknown };
    sf::VideoMode window_size;
    sf::Clock loop_clock;
    sf::Clock cooldown_clock;
    sf::Time delta_time;
    float distance;
    bool quit_game { false };
};


#endif //GAME38_GAME_H
