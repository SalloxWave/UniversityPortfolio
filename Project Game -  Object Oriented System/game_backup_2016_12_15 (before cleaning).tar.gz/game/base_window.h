//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_GUI_H
#define GAME38_GUI_H

#include <string>
#include <vector>
#include <map>

#include <SFML/Graphics/Font.hpp>
#include <SFML/Audio/Music.hpp>
#include <SFML/Audio/Sound.hpp>
#include <SFML/Graphics/Sprite.hpp>

class Base_Window
{
public:
    //Force class to be abstract
    virtual ~Base_Window() = 0;
protected:
    //Window size in here or in other gui classes?, or maybe outside. Maybe change size of window when initializing
    virtual void load_textures() = 0;
    sf::Texture & get_texture(std::string filename);
    sf::Sprite bg_sprite;
    sf::Font font;
    sf::Music music;
    std::vector<sf::Sound> sfx;
    std::map<std::string, sf::Texture> textures;
};

#endif //GAME38_GUI_H
