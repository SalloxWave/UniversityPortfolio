//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_GUI_GAMEBOARD_H
#define GAME38_GUI_GAMEBOARD_H

#include <vector>
#include <map>
#include <string>

#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/RenderWindow.hpp>

#include "base_window.h"
#include "level.h"
#include "player.h"
#include "sprite_with_texture.h"
#include "enum_winning_option.h"
#include "winning_box.h"

class Gameboard: public Base_Window, public sf::RenderWindow
{
public:
    //Get sf::RenderWindow constructor
    using sf::RenderWindow::RenderWindow;
    Gameboard() = default;
    void initialize(Level const & level, Player const & player1, Player const & player2);
    void updateGraphics(Level const & level, Player const & player1, Player const & player2);
private:
    void load_textures() override;
    sf::Sprite player1_sprite;
    sf::Sprite player2_sprite;
    sf::Text player1_name_txt;
    sf::Text player2_name_txt;
    sf::Text player1_life_txt;
    sf::Text player2_life_txt;
    std::vector<sf::Sprite> active_projectiles;
};


#endif //GAME38_GUI_GAMEBOARD_H
