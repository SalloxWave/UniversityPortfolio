//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_ENTITY_H
#define GAME38_ENTITY_H

#include <string>

#include "struct_point.h"
#include "enum_direction.h"

class Entity
{
public:
    void move(Direction direction, unsigned int steps = 1);
    void changeDirection(Direction direction);
    void setPosition(Point pos);
    void setPosition(int x, int y);
    Point getPosition() const;
    std::string getName() const;
    double getSpeed() const;
    unsigned int getWidth() const;
    unsigned int getHeight() const;
    std::string getSpriteSource() const;
    Direction getDirection() const;
protected:
    virtual bool can_move(Direction direction) const = 0;
    std::string name;
    Point position;
    Direction dir;
    double speed;
    unsigned int width;
    unsigned int height;
    std::string sprite_src;
};

#endif //GAME38_ENTITY_H
