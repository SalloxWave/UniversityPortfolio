//
// Created by alexanderjlinux on 11/29/16.
//

#include <fstream>

#include "player.h"

#include "json.hpp"
using json = nlohmann::json;

//Public
Player::Player(unsigned int player_id, bool is_player1 /*= true*/)
{
    std::ifstream json_file {"../resources/data/characters.json"};
    json j;
    json_file >> j;

    int index {0};
    for (int i {0}; i < j.size(); ++i)
    {
        //Found specified index
        if (j[i]["id"] == player_id)
        {
            index = i;
            break;
        }
    }
    //Set player values
    player1 = is_player1;
    max_health = j[index]["max_health"];
    health = max_health;
    dir = player1 ? Direction::Right : Direction::Left;
    sf::Time time {sf::Time::Zero};
    for (int i {0}; i < j[index]["projectiles"].size(); ++i)
    {
        //Connect projectile id to timer
        projectile_ids[j[index]["projectiles"][i]] = time;
    }
    set_controls();
    //Set entity values
    name = j[index]["name"];
    width = j[index]["width"];
    height = j[index]["height"];
    speed = j[index]["speed"];
    sprite_src = j[index]["sprite_src"];
    //Set default values
    state = Player_State::Normal;
}

void Player::setRestrictions(std::array<int, 2> restr)
{
    restrictions = restr;
}

void Player::setRestrictions(int left, int right)
{
    restrictions[0] = left;
    restrictions[1] = right;
}

void Player::setStartPosition(Point position)
{
    start_position = position;
}

void Player::setStartPosition(int x, int y)
{
    start_position.x = x;
    start_position.y = y;
}

bool Player::hasKey(sf::Keyboard::Key key_code) const
{
    //Count amount of keys with specified keycode in controls
    //One is found means player has the specified key
    return (controls.count(key_code) == 1);
}

void Player::shoot(unsigned int projectile_id, sf::Time current_time)
{
    //Check if projectile is ready to use
    if (ready_to_use(projectile_id, current_time))
    {
        Projectile proj { projectile_id };
        //Update cooldown to elapsed time + projectile cooldown
        projectile_ids[projectile_id] = current_time + sf::seconds(static_cast<float>( proj.getCooldown() ));
        if (proj.getState() == Projectile_State::High)
        {
            proj.setPosition(position.x, position.y - height);
        }
        else
        {
            proj.setPosition(position.x, position.y);
        }
        proj.changeDirection(dir);
        active_projectiles.push_back(proj);
    }
}

void Player::removeProjectile(int index)
{
    active_projectiles.erase(active_projectiles.begin()+index);
}

bool Player::collides(Projectile const & projectile) const
{
    int x_diff { 0 };
    //Player is to the left of the projectile
    if ( position.x < projectile.getPosition().x )
    {
        //Get difference
        x_diff = (projectile.getPosition().x + projectile.getWidth()) - position.x;
    }
    //Player is to the right of the projectile
    else
    {
        x_diff = (position.x + width) - projectile.getPosition().x;
    }
    //Total width of player and projectile
    int total_width { width + projectile.getWidth() };

    //Projectile touches player
    if (x_diff <= total_width)
    {
        switch(projectile.getState())
        {
            case Projectile_State::Low:
                //Player did not jump above low projectile
                return (state != Player_State::Jump);
            case Projectile_State::High:
                //Player did not duck under high projectile
                return (state != Player_State::Duck);
        }
    }
    return false;
}

void Player::giveDamage(int amount)
{
    if ( health - amount < 0)
    {
        health = 0;
    }
    else
    {
        health -= amount;
    }
}

bool Player::isDead() const
{
    return (health == 0);
}

void Player::reset()
{
    position = start_position;
    health = max_health;
    state = Player_State::Normal;
}

void Player::setState(Player_State player_state)
{
    state = player_state;
}

Action Player::getAction(sf::Keyboard::Key keycode)
{
    return controls[keycode];
}

std::vector<Projectile> & Player::getActiveProjectiles()
{
    return active_projectiles;
}

std::vector<Projectile> const & Player::getActiveProjectiles() const
{
    return active_projectiles;
}

unsigned int Player::getProjectileId(Projectile_State const & projectile_state) const
{
    for (auto it = begin(projectile_ids); it != end(projectile_ids); ++it)
    {
        Projectile proj { it->first };
        if ( proj.getState() == projectile_state )
        {
            return it->first;
        }
    }
}

std::map<sf::Keyboard::Key, Action> Player::get_controls() const
{
    return controls;
}

Player_State Player::getState() const
{
    return state;
}

int Player::getHealth() const
{
    return health;
}

unsigned int Player::getMaxHealth() const
{
    return max_health;
}

bool Player::isPlayerOne() const
{
    return player1;
}

//Private
bool Player::can_move(Direction direction) const
{
    int distance = direction == Direction::Left ? -1 : 1;
    int tmp_x {getPosition().x + distance};

    return (tmp_x >= restrictions[0]
         && tmp_x <= restrictions[1] - width);
}
void Player::set_controls()
{
    if(player1)
    {
        controls[sf::Keyboard::W] = Action::Jump;
        controls[sf::Keyboard::S] = Action::Duck;
        controls[sf::Keyboard::A] = Action::Left;
        controls[sf::Keyboard::D] = Action::Right;
        controls[sf::Keyboard::R] = Action::ShootLow;
        controls[sf::Keyboard::T] = Action::ShootHigh;
    }
    else
    {
        controls[sf::Keyboard::Up] = Action::Jump;
        controls[sf::Keyboard::Down] = Action::Duck;
        controls[sf::Keyboard::Left] = Action::Left;
        controls[sf::Keyboard::Right] = Action::Right;
        controls[sf::Keyboard::Period] = Action::ShootLow;
        controls[sf::Keyboard::Dash] = Action::ShootHigh;
    }
}

bool Player::ready_to_use(unsigned int projectile_id, sf::Time current_time)
{
    //Check if current time is newer than projectile's time
    return (current_time >= projectile_ids[projectile_id]);
}