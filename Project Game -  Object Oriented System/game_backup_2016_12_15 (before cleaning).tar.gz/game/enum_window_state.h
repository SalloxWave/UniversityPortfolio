//
// Created by alexanderlinux on 12/9/16.
//

#ifndef GAME38_ENUM_WINDOW_STATE_H
#define GAME38_ENUM_WINDOW_STATE_H

enum class Window_State
{
    MainMenu,
    Characterscreen,
    Gameboard
};

#endif //GAME38_ENUM_WINDOW_STATE_H
