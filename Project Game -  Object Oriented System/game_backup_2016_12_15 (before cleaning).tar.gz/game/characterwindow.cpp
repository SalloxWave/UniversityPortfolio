//
// Created by alexanderjlinux on 11/29/16.
//

#include <fstream>
#include <SFML/Graphics/Shape.hpp>

#include "characterwindow.h"

#include "json.hpp"
using json = nlohmann::json;

void Characterwindow::initialize()
{
    //Load all textures for character window
    load_textures();

    max_row_size = 4;
    //Load character portrait images
    load_characters("../resources/data/characters.json");
    //Change start position of players
    player1_selected_id = std::begin(characters)->first;
    player2_selected_id = std::end(characters)->first;

    //Load level portrait images
    load_levels("../resources/data/level_test.json");

    //Load font
    font.loadFromFile("../resources/font/Ubuntu-B.ttf");

    /*Initialize player 1 text*/
    player1_text.setFont(font);
    player1_text.setString("P1");
    player1_text.setPosition(100,100);
    //Move player 1 to first character
    player1_text.setPosition( characters[1].getPosition().x, characters[1].getPosition().y );
    player1_text.setColor(sf::Color::Blue);

    /*Initialize player 2 text*/
    player2_text.setFont(font);
    player2_text.setString("P2");
    //Move player 2 to last character
    player2_text.setPosition( characters[characters.size() - 1].getPosition().x, characters[characters.size() - 1].getPosition().y );
    //sprite_player2.setPosition(500,500);
    player2_text.setColor(sf::Color::Red);

    /*Player 1 controls text*/
    player1_controls.setFont(font);
    player1_controls.setString("W: Jump\nS: Duck\nA: Move left\nD: Move right\nR: Shoot low\nT: Shoot high");
    player1_controls.setPosition(0, getSize().y - player1_controls.getLocalBounds().height - 25);
    /*Player 2 controls text*/
    player2_controls.setFont(font);
    player2_controls.setString("Up-arrow: Jump\nDown-arrow: Duck\nLeft-arrow: Move left\nRight-arrow: Move right\n.: Shoot low\n-: Shoot high");
    player2_controls.setPosition(getSize().x - player2_controls.getLocalBounds().width,
                                 getSize().y - player2_controls.getLocalBounds().height - 25);

    /*Player 1 selected character sprite*/
    player1_selected_character.setTexture(*characters[player1_selected_id].getTexture());
    player1_selected_character.setPosition(player1_controls.getPosition().x + player1_selected_character.getLocalBounds().width,
                                           player1_controls.getPosition().y);

    /*Player 2 selected character sprite*/
    player2_selected_character.setTexture(*characters[player2_selected_id].getTexture());
    player2_selected_character.setPosition(player2_controls.getPosition().x - player2_selected_character.getLocalBounds().width,
                                           player2_controls.getPosition().y);

    /*Player 1 selected character text*/
    player1_selected_text.setFont(font);
    player1_selected_text.setString("Player 1");
    player1_selected_text.setPosition(player1_selected_character.getPosition().x,
                                      player1_selected_character.getPosition().y - player1_selected_text.getLocalBounds().height);
    player1_selected_text.setColor(sf::Color::Blue);

    /*Player 2 selected character text*/
    player2_selected_text.setFont(font);
    player2_selected_text.setString("Player 2");
    player2_selected_text.setPosition(player2_selected_character.getPosition().x,
                                      player2_selected_character.getPosition().y - player2_selected_text.getLocalBounds().height);
    player2_selected_text.setColor(sf::Color::Red);
}

void Characterwindow::updateGraphics()
{
    clear();

    //Draw all selectable characters
    for (auto it = std::begin(characters); it != std::end(characters); ++it)
    {
        draw(it->second);
    }
    //Set position of player text based on player's selected id
    player1_text.setPosition(characters[player1_selected_id].getPosition());
    player2_text.setPosition(characters[player2_selected_id].getPosition());
    //Set texture of selected character based on player's selected character
    player1_selected_character.setTexture(*characters[player1_selected_id].getTexture());
    player2_selected_character.setTexture(*characters[player2_selected_id].getTexture());
    //Draw components to screen
    draw(player1_text);
    draw(player2_text);
    draw(player1_controls);
    draw(player2_controls);
    draw(player1_selected_character);
    draw(player2_selected_character);
    draw(player1_selected_text);
    draw(player2_selected_text);
    display();
}

void Characterwindow::movePlayer(Direction direction, bool is_player1 /*= true*/)
{
    //Get distance from image size of a character image
    int x_distance { characters[1].getLocalBounds().width };
    int y_distance { characters[1].getLocalBounds().height };

    if (can_move_player(direction, is_player1))
    {
        switch(direction)
        {
            //Change selected character id for player based on direction
            //...and move player based on width and height of a character sprite
            case Direction::Up:
                //(is_player1 ? sprite_player1 : sprite_player2).move(0, y_distance * -1);
                if (is_player1) { player1_selected_id -= max_row_size; }
                else { player2_selected_id -= max_row_size; }
                break;
            case Direction::Down:
                //(is_player1 ? sprite_player1 : sprite_player2).move(0, y_distance);
                if (is_player1) { player1_selected_id += max_row_size; }
                else { player2_selected_id += max_row_size; }
                break;
            case Direction::Left:
                //(is_player1 ? sprite_player1 : sprite_player2).move(x_distance * -1, 0);
                if (is_player1) { player1_selected_id -= 1; }
                else { player2_selected_id -= 1; }
                break;
            case Direction::Right:
                //(is_player1 ? sprite_player1 : sprite_player2).move(x_distance, 0);
                if (is_player1) { player1_selected_id += 1; }
                else { player2_selected_id += 1; }
                break;
        }
    }
}

int Characterwindow::getPlayer1CharacterId() const
{
    return player1_selected_id;
}

int Characterwindow::getPlayer2CharacterId() const
{
    return player2_selected_id;
}

bool Characterwindow::can_move_player(Direction direction, bool is_player1 /* = true */)
{
    int new_id_p;

    //Get distance from image size of a character image
    switch (direction)
    {
        //Change selected character id for player based on direction
        //...and return if the character id is a valid character id or not
        case Direction::Up:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) - max_row_size;
            break;
        case Direction::Left:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) - 1;
            break;
        case Direction::Down:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) + max_row_size;
            break;
        case Direction::Right:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) + 1;
            break;
    }
    return characters.count(new_id_p) == 1;
}

void Characterwindow::load_characters(std::string const & filename)
{
    //Open files with characters
    std::ifstream json_file {"../resources/data/characters.json"};
    json char_data;
    json_file >> char_data;

    int char_id;
    int y {0};
    int x {0};
    for (int i {0}; i < char_data.size(); ++i)
    {
        //Get id of character from file
        char_id = char_data[i]["id"];
        //std::cout << char_id << std::endl;
        //Load the texture based on character's image
        std::string texture_src = char_data[i]["portrait_img"];
        //std::cout << get_texture(texture_src).getSize().x << std::endl;
        //Connect character id with character's portrait sprite
        characters[char_id].setTexture(get_texture(texture_src));

        //Set position of sprite
        characters[char_id].setOrigin(characters[char_id].getLocalBounds().width / 2,
                                             characters[char_id].getLocalBounds().height / 2);
        //Check if you should go to next row
        if (x == max_row_size)
        {
            //Go to next row
            ++y;
            x = 0;
        }
        int row_length = max_row_size * characters[char_id].getLocalBounds().width;
        int x_extra = ( getSize().x - row_length) / 2;
        characters[char_id].setPosition(x_extra +  (x * characters[char_id].getLocalBounds().width) + characters[char_id].getOrigin().x,
                                         characters[char_id].getOrigin().y + (y * characters[char_id].getLocalBounds().height) );
        //Go to next column
        ++x;
    }
}

void Characterwindow::load_levels(std::string const & filename)
{
    //Reminder: set origin to middle of image
}

void Characterwindow::load_textures()
{
    //Load character portraits
    std::ifstream char_file {"../resources/data/characters.json"};
    json char_data;
    char_file >> char_data;

    std::string texture_src;
    for (int i {0}; i < char_data.size(); ++i)
    {
        texture_src = char_data[i]["portrait_img"];
        textures[texture_src].loadFromFile("../resources/img/player/" + texture_src);
    }

    //Load level portraits
    std::ifstream level_file {"../resources/data/levels.json"};
    json level_data;
    level_file >> level_data;

    for (int i {0}; i < level_data.size(); ++i)
    {
        texture_src = level_data[i]["portrait_img"];
        textures[texture_src].loadFromFile("../resources/img/level/" + texture_src);
    }
}