//
// Created by alexanderlinux on 12/9/16.
//

#include "game.h"

#include <iostream>

using namespace std;

void Game::run()
{
    //Set window size
    window_size.width = 1580;
    window_size.height = 880;
    window_state = Window_State::MainMenu;
    //Run game as long as something tells to quit_game
    while (!quit_game)
    {
        //Find which window to display and run
        switch(window_state)
        {
            case Window_State::MainMenu:
                run_main_menu();
                break;
            case Window_State::Characterscreen:
                run_character_screen();
                break;
            case Window_State::Gameboard:
                run_gameboard();
                break;
        }
    }
}

void Game::run_main_menu()
{
    Main_Menu main_menu {window_size, "Game 38 - Main Menu"};
    main_menu.setVerticalSyncEnabled(true);
    main_menu.initialize();

    while(main_menu.isOpen())
    {
        while(main_menu.pollEvent(event))
        {
            switch (event.type)
            {
                case sf::Event::Closed:
                    main_menu.close();
                    quit_game = true;
                    break;
                case sf::Event::Resized:
                    printf("You resized the window\n");
                    break;
            }
        }

        // Checking for keyboard clicks
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up))
        {
            main_menu.goUp();
        }
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Down))
        {
            main_menu.goDown();
        }
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Return))
        {
            if(main_menu.getSelectedIndex()==0)
            {
                run_character_screen();
                main_menu.close();
            }
            else
            {
                main_menu.close();
                quit_game = true;
            }
        }

        main_menu.clear();
        main_menu.updateGraphics();
        main_menu.display();
    }
}

void Game::run_character_screen()
{
    //CHARACTER SCREEN TESTING!!!
    Characterwindow characterwindow { window_size, "Character screen, choose wisely!"};
    characterwindow.initialize();

    while(characterwindow.isOpen())
    {
        while(characterwindow.pollEvent(event))
        {
            switch(event.type)
            {
                case sf::Event::Closed:
                    characterwindow.close();
                    quit_game = true;
                    break;
                case sf::Event::KeyPressed:
                    key_code = event.key.code;
            }
        }
        switch(key_code)
        {
            case sf::Keyboard::W:
                characterwindow.movePlayer(Direction::Up, true);
                break;
            case sf::Keyboard::A:
                characterwindow.movePlayer(Direction::Left, true);
                break;
            case sf::Keyboard::S:
                characterwindow.movePlayer(Direction::Down, true);
                break;
            case sf::Keyboard::D:
                characterwindow.movePlayer(Direction::Right, true);
                break;
            case sf::Keyboard::Up:
                characterwindow.movePlayer(Direction::Up, false);
                break;
            case sf::Keyboard::Left:
                characterwindow.movePlayer(Direction::Left, false);
                break;
            case sf::Keyboard::Down:
                characterwindow.movePlayer(Direction::Down, false);
                break;
            case sf::Keyboard::Right:
                characterwindow.movePlayer(Direction::Right, false);
                break;
            case sf::Keyboard::Return:
                player1_selected_id = characterwindow.getPlayer1CharacterId();
                player2_selected_id = characterwindow.getPlayer2CharacterId();
                characterwindow.close();
                window_state = Window_State::Gameboard;
                break;
            case sf::Keyboard::Escape:
                characterwindow.close();
                window_state = Window_State::MainMenu;
                break;

        }
        characterwindow.updateGraphics();
        //Reset key event
        key_code = sf::Keyboard::Unknown;
    }
}

void Game::run_gameboard()
{
    //Create level
    Level level { 1 };
    //Create players
    Player player1 { player1_selected_id, true };
    Player player2 { player2_selected_id, false };
    //Add players to level
    level.addPlayer(player1, true);
    level.addPlayer(player2, false);
    //Set window height
    window_size.width = level.getWidth();
    window_size.height = level.getHeight();
    //Open and initialize gameboard window
    Gameboard gameboard{ window_size, "Gameboard, fight!" };
    gameboard.initialize(level, player1, player2);

    while(gameboard.isOpen())
    {
        while (gameboard.pollEvent(event))
        {
            switch (event.type)
            {
                case sf::Event::Closed:
                    gameboard.close();
                    quit_game = true;
                    break;
                case sf::Event::KeyPressed:
                    key_code = event.key.code;
            }
        }

        //Get time it took for one iteration
        delta_time = loop_clock.restart();
        // Player 1 keys
        std::map<sf::Keyboard::Key, Action> player1controls {player1.get_controls()};
        for (auto it = std::begin(player1controls); it != std::end(player1controls); ++it)
        {
            if(sf::Keyboard::isKeyPressed(it->first))
            {
                switch (it->second)
                {
                    case Action::Left:
                        if(player1.getState() == Player_State::Normal)
                        {
                            distance = delta_time.asMilliseconds() * player1.getSpeed() / 2;
                            player1.move(Direction::Left, distance);
                        }
                        player1.setState(Player_State::Normal);
                        break;
                    case Action::Right:
                        if(player1.getState() == Player_State::Normal)
                        {
                            distance = delta_time.asMilliseconds() * player1.getSpeed() / 2;
                            player1.move(Direction::Right, distance);
                        }
                        player1.setState(Player_State::Normal);
                        break;
                    case Action::Jump:
                        player1.setState(Player_State::Jump);
                        //cout << "Player 1 Jumping" << endl;
                        break;
                    case Action::Duck:
                        player1.setState(Player_State::Duck);
                        //cout << "Player 1 Ducking" << endl;
                        break;
                    case Action::ShootLow:
                    {
                        int proj_id = player1.getProjectileId(Projectile_State::Low);
                        player1.shoot(proj_id, cooldown_clock.getElapsedTime());
                        player1.setState(Player_State::ShootLow);
                        //cout << "Player 1 shot low projectile with id " << proj_id << endl;
                        break;
                    }
                    case Action::ShootHigh:
                    {
                        int proj_id2 = player1.getProjectileId(Projectile_State::High);
                        player1.shoot(proj_id2, cooldown_clock.getElapsedTime());
                        player1.setState(Player_State::ShootHigh);
                        //cout << "Player 1 shot high projectile with id " << proj_id2 << endl;
                        break;
                    }
                }
            }
        }

        // Player 2 keys
        std::map<sf::Keyboard::Key, Action> player2controls {player2.get_controls()};
        for (auto it = std::begin(player2controls); it != std::end(player2controls); ++it)
        {
            if(sf::Keyboard::isKeyPressed(it->first))
            {
                switch (it->second)
                {
                    case Action::Left:
                        if(player2.getState() == Player_State::Normal)
                        {
                            distance = delta_time.asMilliseconds() * player2.getSpeed() / 2;
                            player2.move(Direction::Left, 10);
                        }
                        player2.setState(Player_State::Normal);
                        break;
                    case Action::Right:
                        if(player2.getState() == Player_State::Normal)
                        {
                            distance = delta_time.asMilliseconds() * player2.getSpeed() / 2;
                            player2.move(Direction::Right, 10);
                        }
                        player2.setState(Player_State::Normal);
                        break;
                    case Action::Jump:
                        player2.setState(Player_State::Jump);
                        //cout << "Player 2 Jumping" << endl;
                        break;
                    case Action::Duck:
                        player2.setState(Player_State::Duck);
                        //cout << "Player 2 Ducking" << endl;
                        break;
                    case Action::ShootLow:
                    {
                        int proj_id = player2.getProjectileId(Projectile_State::Low);
                        player2.shoot(proj_id, cooldown_clock.getElapsedTime());
                        player2.setState(Player_State::ShootLow);
                        //cout << "Player 2 shot low projectile with id " << proj_id << endl;
                        break;
                    }
                    case Action::ShootHigh:
                    {
                        int proj_id2 = player2.getProjectileId(Projectile_State::High);
                        player2.shoot(proj_id2, cooldown_clock.getElapsedTime());
                        player2.setState(Player_State::ShootHigh);
                        //cout << "Player 2 shot high projectile with id " << proj_id2 << endl;
                        break;
                    }
                }
            }
        }

        //Update logic
        for (int i {0}; i < player1.getActiveProjectiles().size(); ++i)
        {
            if(player1.getActiveProjectiles()[i].collides(level))
            {
                player1.removeProjectile(i);
            }
            else if(player2.collides(player1.getActiveProjectiles()[i]))
            {
                player2.giveDamage(player1.getActiveProjectiles()[i].getDamage());
                player1.removeProjectile(i);
            }
            else
            {
                distance = delta_time.asMilliseconds() * player1.getActiveProjectiles()[i].getSpeed() / 2;
                player1.getActiveProjectiles()[i].move(player1.getActiveProjectiles()[i].getDirection(), distance);
            }
        }

        for (int i {0}; i < player2.getActiveProjectiles().size(); ++i)
        {
            if(player2.getActiveProjectiles()[i].collides(level))
            {
                player2.removeProjectile(i);
            }
            else if(player1.collides(player2.getActiveProjectiles()[i]))
            {
                player1.giveDamage(player2.getActiveProjectiles()[i].getDamage());
                player2.removeProjectile(i);
            }
            else
            {
                distance = delta_time.asMilliseconds() * player2.getActiveProjectiles()[i].getSpeed() / 2;
                player2.getActiveProjectiles()[i].move(player2.getActiveProjectiles()[i].getDirection(), distance);
            }
        }
        //Update graphics of board based on game objects
        gameboard.updateGraphics(level, player1, player2);

        //If any player has died
        if (player1.isDead() || player2.isDead())
        {
            //Create winning box without borders
            Winning_Box winning_box{ sf::VideoMode(790, 440), "Winning screen, who is the winner?" };
            //Initialize winning box based on the winner
            if (player1.isDead())
            {
                winning_box.initialize(player2);
            }
            else
            {
                winning_box.initialize(player1);
            }
            while (winning_box.isOpen())
            {
                //To avoid going more than one step at a time
                sf::sleep(sf::seconds(0.1));
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
                {
                    switch(winning_box.getWinningOption())
                    {
                        case Winning_Option::PlayAgain:
                            //Reload the level to be able to play again
                            level.reload();
                            break;
                        case Winning_Option::ChangeCharacter:
                            gameboard.close();
                            window_state = Window_State::Characterscreen;
                            break;
                        case Winning_Option::ExitGame:
                            gameboard.close();
                            quit_game = true;
                            break;
                    }
                    winning_box.close();
                }
                else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
                {
                    winning_box.goUp();
                }
                else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
                {
                    winning_box.goDown();
                }
                winning_box.updateGraphics();
            }
        }

        //Reset keycode
        //Reset states
        //player1.setState(Player_State::Normal);
        //player2.setState(Player_State::Normal);
    }
}
