#include "game.h"

using namespace std;

int main()
{
    Game game;
    game.run();
    cout << "Exited the game" << endl;
    return 0;
}