//
// Created by alejo720 on 2016-12-02.
//

#ifndef GAME38_ENUM_DIRECTION_H
#define GAME38_ENUM_DIRECTION_H

enum class Direction
{
    Left,
    Right,
    Up,
    Down
};

#endif //GAME38_ENUM_DIRECTION_H
