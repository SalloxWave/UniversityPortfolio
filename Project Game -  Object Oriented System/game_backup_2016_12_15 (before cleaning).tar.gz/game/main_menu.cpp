//
// Created by alexanderjlinux on 11/29/16.
//

#include "main_menu.h"
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Text.hpp>
#include "base_window.h"
#include "struct_point.h"
#include <SFML/Graphics.hpp>

#include <fstream>

#include "json.hpp"
using json = nlohmann::json;

void Main_Menu::initialize()
{
    //Load the textures for the main menu
    load_textures();

    selected_index = 0;

    // Background
    background.setTexture(get_texture("main_menu_bg.png"));
    Point bgPos {0,0};
    background.setPosition(bgPos.x, bgPos.y);

    // Logo
    logo_img.setTexture(get_texture("logo.png"));
    Point logoPos {250,50};
    logo_img.setPosition(logoPos.x, logoPos.y);
    logo_img.scale(0.15f, 0.15f);

    // Start button
    btn_start_game.setTexture(get_texture("menu.png"));
    Point startPos {300,250};
    btn_start_game.setPosition(startPos.x, startPos.y);
    btn_start_game.scale(0.2f, 0.2f);

    // Exit button
    btn_exit_game.setTexture(get_texture("menu.png"));
    Point exitPos {300,320};
    btn_exit_game.setPosition(exitPos.x, exitPos.y);
    btn_exit_game.scale(0.2f, 0.2f);

    // Credits Text
    font.loadFromFile("../resources/font/Ubuntu-B.ttf");
    credits.setFont(font); // font is a sf::Font
    credits.setString("Credits: Alexander Jonsson, Joakim Johansson");
    credits.setCharacterSize(18); // in pixels, not points!
    credits.setColor(sf::Color(255,255,255,100));
    credits.setStyle(sf::Text::Italic);
    credits.setPosition(200.0f, 550.0f);

    // Selected Info Text
    selected_info.setFont(font); // font is a sf::Font
    selected_info.setCharacterSize(14); // in pixels, not points!
    selected_info.setColor(sf::Color(255,255,255,120));
    selected_info.setPosition(300.0f, 390.0f);

}

void Main_Menu::updateGraphics()
{
    // left top width height
    btn_start_game.setTextureRect(sf::IntRect(0, (selected_index==0?300:0), 1000, 280));
    btn_exit_game.setTextureRect(sf::IntRect(1000, (selected_index==1?300:0), 1000, 280));
    if(selected_index==0)
    {
        selected_info.setString("Press Enter to Play Game");
    }
    else
    {
        selected_info.setString("Press Enter to Exit Game");
    }

    draw(background);
    draw(logo_img);
    draw(btn_start_game);
    draw(btn_exit_game);
    draw(credits);
    draw(selected_info);
}

void Main_Menu::goUp()
{
    if(selected_index == 1)
    {
        selected_index = 0;
    }
}
void Main_Menu::goDown()
{
    if(selected_index == 0)
    {
        selected_index = 1;
    }
}
int Main_Menu::getSelectedIndex()
{
    return selected_index;
}

void Main_Menu::load_textures()
{
    //Load character portraits
    textures["main_menu_bg.png"].loadFromFile("../resources/img/main_menu_bg.png");
    textures["logo.png"].loadFromFile("../resources/img/logo.png");
    textures["menu.png"].loadFromFile("../resources/img/menu.png");
}
