//
// Created by alexanderjlinux on 11/29/16.
//

#include "gameboard.h"

#include <fstream>

void Gameboard::initialize(Level const & level, Player const & player1, Player const & player2)
{
    load_textures();
    //
    //OBS: Temporary changed music source to sfx wav files because MP3 files are not supported
    //Also changed temporary images for players because no player sprites yet

    //Load image of level from the specified level's image source
    bg_sprite.setTexture(get_texture(level.getBgSource()));
    //std::cout << get_texture(level.getBgSource()).getSize().x << std::endl;
    //Load music of level from specified level's music source
    //music.openFromFile("../resources/sfx/" + level.getMusicSource());
    music.openFromFile("../resources/music/awesome_music.ogg");
    music.play();

    /*Initialize player sprite for player 1*/
    player1_sprite.setTexture(get_texture(player1.getSpriteSource()));
    // Left Top Width Height
    player1_sprite.setTextureRect(sf::IntRect(190, 0, 190, 220));
    //Move origin upwards based on player height to make y position be on the feet of the player
    //Should be player.getwidth when having correct player images
    player1_sprite.setOrigin(0, player1_sprite.getLocalBounds().height);
    player1_sprite.setPosition(player1.getPosition().x, player1.getPosition().y);

    /*Initialize player sprite for player 2*/
    player2_sprite.setTexture(get_texture(player2.getSpriteSource()));
    // Left Top Width Height
    player2_sprite.setTextureRect(sf::IntRect(190, 0, 190, 220));
    //Move origin upwards based on player height to make y position be on the feet of the player
    //Should be player.getwidth when having correct player images
    player2_sprite.setOrigin(0 + player2_sprite.getLocalBounds().width, player2_sprite.getLocalBounds().height);
    player2_sprite.scale(-1.f,1.f);
    player2_sprite.setPosition(player2.getPosition().x, player2.getPosition().y);

    //Load the font
    font.loadFromFile("../resources/font/Ubuntu-B.ttf");

    /*Initialize name text for player 1*/
    player1_name_txt.setFont(font);
    player1_name_txt.setString(player1.getName());
    player1_name_txt.setPosition(0, 0);

    /*Initialize name text for player 2*/
    player2_name_txt.setFont(font);
    player2_name_txt.setString(player2.getName());
    player2_name_txt.setPosition(level.getWidth() - player2_name_txt.getLocalBounds().width, 0);

    /*Initialize health text for player 1*/
    player1_life_txt.setFont(font);
    player1_life_txt.setString(std::to_string(player1.getHealth()) + "/"
                               + std::to_string(player1.getMaxHealth()));
    player1_life_txt.setPosition(0, player1_name_txt.getLocalBounds().height);

    /*Initialize health text for player 2*/
    player2_life_txt.setFont(font);
    player2_life_txt.setString(std::to_string(player2.getHealth()) + "/"
                               + std::to_string(player2.getMaxHealth()));
    player2_life_txt.setPosition(level.getWidth() - player2_life_txt.getLocalBounds().width,
                                 player2_name_txt.getLocalBounds().height);
    std::cout << "init gameboard" << std::endl;

}

void Gameboard::updateGraphics(Level const & level, Player const & player1, Player const & player2)
{
    //Update position of player sprites
    player1_sprite.setPosition(player1.getPosition().x, player1.getPosition().y);
    player2_sprite.setTextureRect(sf::IntRect(190, 0, 190, 220)); // Left Top Width Height

    //Update Player Texture depending on the players state
    player1_sprite.setPosition(player1.getPosition().x, player1.getPosition().y);
    switch (player1.getState())
    {
        case Player_State::Jump:
            player1_sprite.setTextureRect(sf::IntRect(0, 440, 190, 220)); // Left Top Width Height
            break;
        case Player_State::Duck:
            player1_sprite.setTextureRect(sf::IntRect(190, 440, 190, 220)); // Left Top Width Height
            break;
        case Player_State::ShootLow:
            player1_sprite.setTextureRect(sf::IntRect(220, 220, 190, 220)); // Left Top Width Height
            break;
        case Player_State::ShootHigh:
            player1_sprite.setTextureRect(sf::IntRect(0, 220, 190, 220)); // Left Top Width Height
            break;
        default:
            player1_sprite.setTextureRect(sf::IntRect(190, 0, 190, 220)); // Left Top Width Height
            break;
    }

    player2_sprite.setPosition(player2.getPosition().x, player2.getPosition().y);
    switch (player2.getState())
    {
        case Player_State::Jump:
            player2_sprite.setTextureRect(sf::IntRect(0, 440, 190, 220)); // Left Top Width Height
            break;
        case Player_State::Duck:
            player2_sprite.setTextureRect(sf::IntRect(190, 440, 190, 220)); // Left Top Width Height
            break;
        case Player_State::ShootLow:
            player2_sprite.setTextureRect(sf::IntRect(220, 220, 190, 220)); // Left Top Width Height
            break;
        case Player_State::ShootHigh:
            player2_sprite.setTextureRect(sf::IntRect(0, 220, 190, 220)); // Left Top Width Height
            break;
        default:
            player2_sprite.setTextureRect(sf::IntRect(190, 0, 190, 220)); // Left Top Width Height
            break;
    }


    //Update life text of players
    player1_life_txt.setString(std::to_string(player1.getHealth()) + "/"
                               + std::to_string(player1.getMaxHealth()));
    player2_life_txt.setString(std::to_string(player2.getHealth()) + "/"
                               + std::to_string(player2.getMaxHealth()));

    //Draw active projectiles
    active_projectiles.clear();
    for (Projectile proj: player1.getActiveProjectiles())
    {
        sf::Sprite proj_sprite;
        std::string sprite_src = proj.getSpriteSource();
        //std::cout << sprite_src << std::endl;
        proj_sprite.setTexture(get_texture(sprite_src));
        proj_sprite.setPosition(proj.getPosition().x, proj.getPosition().y);
        //std::cout << "x: " << proj_sprite.getPosition().x << std::endl;
        //std::cout << "y: " << proj_sprite.getPosition().y << std::endl;
        active_projectiles.push_back(proj_sprite);
    }
    for (Projectile proj: player2.getActiveProjectiles())
    {
        sf::Sprite proj_sprite;
        std::string sprite_src = proj.getSpriteSource();
        //std::cout << sprite_src << std::endl;
        proj_sprite.setTexture(get_texture(sprite_src));
        proj_sprite.setPosition(proj.getPosition().x, proj.getPosition().y);
        //std::cout << "x: " << proj_sprite.getPosition().x << std::endl;
        //std::cout << "y: " << proj_sprite.getPosition().y << std::endl;
        active_projectiles.push_back(proj_sprite);
    }

    //Draw to window
    std::cout << "updating graphics" << std::endl;
    clear();
    draw(bg_sprite);
    draw(player1_sprite);
    draw(player2_sprite);
    for (int i {0}; i < active_projectiles.size(); ++i)
    {
        //std::cout << active_projectiles.size() << std::endl;
        draw(active_projectiles[i]);
    }
    draw(player1_life_txt);
    draw(player2_life_txt);
    draw(player1_name_txt);
    draw(player2_name_txt);
    display();
}

void Gameboard::load_textures()
{
    //Load character textures
    std::ifstream char_file {"../resources/data/characters.json"};
    json char_data;
    char_file >> char_data;

    //Load projectile textures
    std::string sprite_src;
    for (int i {0}; i < char_data.size(); ++i)
    {
        sprite_src = char_data[i]["sprite_src"];
        textures[sprite_src].loadFromFile("../resources/img/player/" + sprite_src);
    }

    //Load projectile textures
    std::ifstream proj_file {"../resources/data/projectiles.json"};
    json proj_data;
    proj_file >> proj_data;

    //Load projectile textures
    for (int i {0}; i < proj_data.size(); ++i)
    {
        sprite_src = proj_data[i]["sprite_src"];
        textures[sprite_src].loadFromFile("../resources/img/projectile/" + sprite_src);
    }

    //Load level background textures
    std::ifstream level_file {"../resources/data/levels.json"};
    json level_data;
    level_file >> level_data;

    //Load projectile textures
    for (int i {0}; i < level_data.size(); ++i)
    {
        sprite_src = level_data[i]["bg_src"];
        textures[sprite_src].loadFromFile("../resources/img/level/" + sprite_src);
    }
}