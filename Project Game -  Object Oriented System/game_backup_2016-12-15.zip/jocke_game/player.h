//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_PLAYER_H
#define GAME38_PLAYER_H

#include <string>
#include <vector>
#include <array>
#include <map>

#include <SFML/Window/Keyboard.hpp>
#include <SFML/System/Time.hpp>

#include "entity.h"
class Projectile;
#include "projectile.h"
enum class Projectile_State;
#include "enum_projectile_state.h"
#include "enum_player_state.h"
#include "enum_action.h"

class Player: public Entity
{
public:
    Player() = default;
    Player(unsigned int player_id, bool is_player1 = true);
    void setRestrictions(std::array<int, 2> restrictions);
    void setRestrictions(int left, int right);
    void setStartPosition(Point position);
    void setStartPosition(int x, int y);
    bool hasKey(sf::Keyboard::Key key_code) const;
    void shoot(unsigned int projectile_id, sf::Time current_time);
    void removeProjectile(int index);
    bool collides(Projectile const & projectile) const;
    void giveDamage(int amount);
    bool isDead() const;
    void reset();
    void setState(Player_State state);
    Action getAction(sf::Keyboard::Key keycode);
    std::map<sf::Keyboard::Key, Action> get_controls() const;
    std::vector<Projectile> & getActiveProjectiles();
    std::vector<Projectile> const & getActiveProjectiles() const;
    unsigned int getProjectileId(Projectile_State const & projectile_state) const;
    Player_State getState() const;
    int getHealth() const;
    unsigned int getMaxHealth() const;
    bool isPlayerOne() const;
private:
    bool can_move(Direction direction) const override;
    void set_controls();
    bool ready_to_use(unsigned int projectile_id, sf::Time current_time);
    bool player1;
    unsigned int max_health;
    int health;
    Point start_position;
    Player_State state;
    std::vector<Projectile> active_projectiles;
    std::map<unsigned int, sf::Time> projectile_ids;
    std::array<int, 2> restrictions;
    std::map<sf::Keyboard::Key, Action> controls;
};

#endif //GAME38_PLAYER_H
