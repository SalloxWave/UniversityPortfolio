//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_LEVEL_H
#define GAME38_LEVEL_H

#include <string>
#include <array>

#include "json.hpp"

class Player;
#include "player.h"

using json = nlohmann::json;

class Level
{
public:
    Level() = default;
    Level(unsigned int level_id);
    void addPlayer(Player &player, bool is_player1 = true);
    void reload();
    std::string getName() const;
    unsigned int getWidth() const;
    unsigned int getHeight() const;
    std::string getBgSource() const;
    std::string getMusicSource() const;
private:
    std::string name;
    unsigned int width;
    unsigned int height;
    int y_level;
    std::array<int, 2> restriction_left;
    std::array<int, 2> restriction_right;
    Player* player1;
    Player* player2;
    std::string bg_src;
    std::string music_src;
};


#endif //GAME38_LEVEL_H
