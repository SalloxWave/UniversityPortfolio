//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_GUI_CHARACTERSCREEN_H
#define GAME38_GUI_CHARACTERSCREEN_H

#include <string>
#include <vector>
#include <array>
#include <map>

#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/RectangleShape.hpp>

#include "base_window.h"
#include "enum_direction.h"

#include "json.hpp"

using json = nlohmann::json;

class Characterwindow: public Base_Window, public sf::RenderWindow
{
public:
    //Get sf::RenderWindow constructor
    using sf::RenderWindow::RenderWindow;
    Characterwindow() = default;
    void initialize();
    void updateGraphics();
    void movePlayer(Direction direction, bool is_player1 = true);
    int getPlayer1CharacterId() const;
    int getPlayer2CharacterId() const;
private:
    void load_textures() override;
    void load_characters(std::string const & filename);
    void load_levels(std::string const & filename);
    bool can_move_player(Direction direction, bool is_player1 = true);
    unsigned int max_row_size;
    std::map<int, sf::Sprite> characters;
    std::map<int, sf::Sprite> level_sprites;
    int player1_selected_id;
    int player2_selected_id;
    sf::Text player1_text;
    sf::RectangleShape player1_text_bg;
    sf::Text player2_text;
    sf::RectangleShape player2_text_bg;
    sf::Sprite player1_selected_character;
    sf::Sprite player2_selected_character;
    sf::Sprite background;
    sf::Text player1_selected_text;
    sf::Text player1_selected_text_medium;
    sf::Text player1_selected_text_small;
    sf::Text player2_selected_text;
    sf::Text player2_selected_text_medium;
    sf::Text player2_selected_text_small;
    sf::Text player1_controls;
    sf::Text player2_controls;
    sf::Text enterToPlay_text;
    int enterToPlay_opacity;
    bool enterToPlay_opacity_state;
    json char_data;
    json projectile_data;
};

#endif //GAME38_GUI_CHARACTERSCREEN_H
