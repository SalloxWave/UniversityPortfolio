//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_STRUCT_POINT_H
#define GAME38_STRUCT_POINT_H
struct Point
{
    Point()
        : x {0}, y {0}
    {}
    Point(int _x, int _y)
        : x {_x}, y {_y}
    {}
    int x {0};
    int y {0};
};

#endif //GAME38_STRUCT_POINT_H
