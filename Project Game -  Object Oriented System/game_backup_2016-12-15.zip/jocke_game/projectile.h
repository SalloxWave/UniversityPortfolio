//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_PROJECTILE_H
#define GAME38_PROJECTILE_H

#include <fstream>

#include "json.hpp"
using json = nlohmann::json;

#include "entity.h"
class Level;
#include "level.h"
#include "enum_projectile_state.h"

class Projectile: public Entity
{
public:
    Projectile() = default;
    Projectile(unsigned int projectile_id);
    bool collides(Level const & level) const;
    void setState(Projectile_State projectile_state);
    int getDamage() const;
    double getCooldown() const;
    Projectile_State getState() const;
private:
    bool can_move(Direction direction) const override;
    int damage;
    double cooldown;
    Projectile_State state;
};


#endif //GAME38_PROJECTILE_H
