//
// Created by alexanderjlinux on 11/29/16.
//

#ifndef GAME38_GUI_MAIN_MENU_H
#define GAME38_GUI_MAIN_MENU_H

#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/RenderWindow.hpp>

#include "base_window.h"
#include "sprite_with_texture.h"

class Main_Menu: public Base_Window, public sf::RenderWindow
{
public:
    //Get sf::RenderWindow constructor
    using sf::RenderWindow::RenderWindow;
    Main_Menu() = default;

    void initialize();
    void updateGraphics();
    void goUp();
    void goDown();
    int getSelectedIndex();
private:
    void load_textures() override;
    sf::Sprite btn_start_game;
    sf::Sprite btn_exit_game;
    sf::Sprite background;
    sf::Sprite logo_img;
    sf::Text credits;
    sf::Text selected_info;
    int selected_index;
};


#endif //GAME38_GUI_MAIN_MENU_H