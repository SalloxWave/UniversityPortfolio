//
// Created by alexanderlinux on 12/10/16.
//

#ifndef GAME38_SPRITE_WITH_TEXTURE_H
#define GAME38_SPRITE_WITH_TEXTURE_H

#include <string>

#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>

class Sprite_With_Texture: public sf::Sprite
{
public:
    Sprite_With_Texture() = default;
    void setTextureFromFile(std::string filepath);
private:
    sf::Texture texture;
};


#endif //GAME38_SPRITE_WITH_TEXTURE_H
