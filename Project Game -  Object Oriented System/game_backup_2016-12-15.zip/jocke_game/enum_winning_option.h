//
// Created by alejo720 on 2016-12-14.
//

#ifndef GAME38_ENUM_WINNING_OPTION_H
#define GAME38_ENUM_WINNING_OPTION_H

enum class Winning_Option
{
    PlayAgain,
    ChangeCharacter,
    ExitGame
};

#endif //GAME38_ENUM_WINNING_OPTION_H
