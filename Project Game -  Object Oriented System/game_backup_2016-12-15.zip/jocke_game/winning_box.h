//
// Created by alejo720 on 2016-12-14.
//

#ifndef GAME38_WINNING_BOX_H
#define GAME38_WINNING_BOX_H

#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/RenderWindow.hpp>

#include "base_window.h"
#include "player.h"
#include "enum_winning_option.h"

class Winning_Box: public Base_Window, public sf::RenderWindow
{
public:
    //Get sf::RenderWindow constructor
    using sf::RenderWindow::RenderWindow;
    Winning_Box() = default;
    void initialize(Player const & winner);
    void updateGraphics();
    void goUp();
    void goDown();
    Winning_Option getWinningOption();
private:
    void load_textures() override;
    int selected_index;
    sf::Text text_winner;
    sf::Text text_play_again;
    sf::Text text_change_character;
    sf::Text text_exit_game;
};


#endif //GAME38_WINNING_BOX_H
