//
// Created by alejo720 on 2016-12-14.
//

#include "winning_box.h"

void Winning_Box::initialize(Player const & winner)
{
    selected_index = 0;

    //Load the font
    font.loadFromFile("../resources/font/Ubuntu-B.ttf");

    /*Initialize play again text*/
    text_play_again.setFont(font);
    text_play_again.setString("Play again");
    text_play_again.setPosition(0,0);
    /*Initialize change character text*/
    text_change_character.setFont(font);
    text_change_character.setString("Change characters");
    text_change_character.setPosition(0, text_play_again.getPosition().y + text_change_character.getLocalBounds().height);
    /*Initialize exit game text*/
    text_exit_game.setFont(font);
    text_exit_game.setString("Exit game");
    text_exit_game.setPosition(0, text_change_character.getPosition().y + text_exit_game.getLocalBounds().height);

    /*Initialize winner text*/
    text_winner.setFont(font);
}

void Winning_Box::updateGraphics()
{
    switch(getWinningOption())
    {
        case Winning_Option::PlayAgain:
            text_play_again.setColor(sf::Color::Yellow);
            text_change_character.setColor(sf::Color::White);
            text_exit_game.setColor(sf::Color::White);
            break;
        case Winning_Option::ChangeCharacter:
            text_change_character.setColor(sf::Color::Yellow);
            text_play_again.setColor(sf::Color::White);
            text_exit_game.setColor(sf::Color::White);
            break;
        case Winning_Option::ExitGame:
            text_exit_game.setColor(sf::Color::Yellow);
            text_play_again.setColor(sf::Color::White);
            text_change_character.setColor(sf::Color::White);
            break;
    }
    clear();
    draw(text_play_again);
    draw(text_change_character);
    draw(text_exit_game);
    display();
}

Winning_Option Winning_Box::getWinningOption()
{
    Winning_Option winning_option {Winning_Option::PlayAgain};
    switch(selected_index)
    {
        case 0:
            winning_option = Winning_Option::PlayAgain;
            break;
        case 1:
            winning_option = Winning_Option::ChangeCharacter;
            break;
        case 2:
            winning_option = Winning_Option::ExitGame;
            break;
    }
    return winning_option;
}

void Winning_Box::goUp()
{
    //Go up if selected option is not at the top
    if (selected_index != 0)
    {
        selected_index-=1;
    }
}

void Winning_Box::goDown()
{
    //Go down if selected option is not at the bottom
    if (selected_index != 2)
    {
        selected_index+=1;
    }
}

void Winning_Box::load_textures()
{

}