//
// Created by alexanderjlinux on 11/29/16.
//

#include "base_window.h"

Base_Window::~Base_Window() = default;

sf::Texture & Base_Window::get_texture(std::string filename)
{
    return textures[filename];
}
