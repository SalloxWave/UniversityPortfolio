//
// Created by alexanderjlinux on 11/29/16.
//

#include <fstream>
#include <SFML/Graphics/Shape.hpp>
#include "characterwindow.h"
#include "json.hpp"
#include "struct_point.h"

using json = nlohmann::json;

void Characterwindow::initialize()
{
    //Open files with characters
    std::ifstream json_file {"../resources/data/characters.json"};
    json_file >> char_data;
    std::ifstream json_file2 {"../resources/data/projectiles.json"};
    json_file2 >> projectile_data;

    //Load all textures for character window
    load_textures();

    max_row_size = 4;
    //Load character portrait images
    load_characters("../resources/data/characters.json");
    //Change start position of players
    player1_selected_id = std::begin(characters)->first;
    player2_selected_id = std::end(characters)->first;

    //Load level portrait images
    load_levels("../resources/data/level_test.json");

    //Load font
    font.loadFromFile("../resources/font/Ubuntu-B.ttf");

    // Background
    background.setTexture(get_texture("characterscreen_background.png"));
    Point bgPos {0,0};
    background.setPosition(bgPos.x, bgPos.y);

    /*Initialize player 1 text*/
    player1_text.setFont(font);
    player1_text.setString("P1");
    player1_text.setOrigin(player1_text.getLocalBounds().width/2, player1_text.getLocalBounds().height/2);
    //player1_text.setPosition(100,100);
    //Move player 1 to first character
    //player1_text.setPosition( characters[1].getPosition().x + 7, characters[1].getPosition().y);
    player1_text.setColor(sf::Color::White);

    /*Initialize player 2 text*/
    player2_text.setFont(font);
    player2_text.setString("P2");
    player2_text.setOrigin(player2_text.getLocalBounds().width/2, player2_text.getLocalBounds().height/2);
    //Move player 2 to last character
    //player2_text.setPosition( characters[characters.size() - 1].getPosition().x, characters[characters.size() - 1].getPosition().y );
    //sprite_player2.setPosition(500,500);
    player2_text.setColor(sf::Color::White);

    // Player 1 text background
    player1_text_bg.setSize(sf::Vector2f(player1_text.getLocalBounds().width + 40, player1_text.getLocalBounds().height + 40));
    player1_text_bg.setFillColor(sf::Color(57, 142, 209, 160));
    player1_text_bg.setOrigin(player1_text_bg.getLocalBounds().width/2, player1_text_bg.getLocalBounds().height/2);

    // Player 2 text background
    player2_text_bg.setSize(sf::Vector2f(player2_text.getLocalBounds().width + 40, player2_text.getLocalBounds().height + 40));
    player2_text_bg.setFillColor(sf::Color(255, 0, 6, 100));
    player2_text_bg.setOrigin(player2_text_bg.getLocalBounds().width/2, player2_text_bg.getLocalBounds().height/2);

    /*Player 1 controls text*/
    player1_controls.setFont(font);
    player1_controls.setCharacterSize(20);
    player1_controls.setString("W\nS\nA\nD\nR\nT");
    player1_controls.setColor(sf::Color(185,185,185,255));
    player1_controls.setPosition(216, 182);

    /*Player 2 controls text*/
    player2_controls.setFont(font);
    player2_controls.setCharacterSize(20);
    player2_controls.setString("Up-arrow\nDown-arrow\nLeft-arrow\nRight-arrow\n.\n-");
    player2_controls.setColor(sf::Color(185,185,185,255));
    player2_controls.setPosition(1396, 182);

    /*Player 1 selected character sprite*/
    player1_selected_character.setTexture(*characters[player1_selected_id].getTexture());
    player1_selected_character.setPosition(382, 622);

    /*Player 2 selected character sprite*/
    player2_selected_character.setTexture(*characters[player2_selected_id].getTexture());
    player2_selected_character.setPosition(1000, 623);
    player2_selected_character.setOrigin(player2_selected_character.getLocalBounds().width, 0);
    player2_selected_character.setScale(-1.f, 1.f);

    /* "Press Enter to Start" text */
    enterToPlay_opacity = 255;
    enterToPlay_opacity_state = true;
    enterToPlay_text.setFont(font);
    enterToPlay_text.setCharacterSize(20);
    enterToPlay_text.setString("Press Enter when\neveryone is Ready");
    enterToPlay_text.setOrigin(enterToPlay_text.getLocalBounds().width/2, enterToPlay_text.getLocalBounds().height/2);
    //enterToPlay_text.setColor(sf::Color(255, 255, 255, enterToPlay_opacity));
    enterToPlay_text.setPosition(800, 690);
    enterToPlay_text.setStyle(sf::Text::Italic);



    //Player 1 selected character NAME, OTHER TEXT AND PROJECTILES TEXT
    player1_selected_text.setFont(font);
    player1_selected_text.setCharacterSize(30);
    player1_selected_text.setPosition(70, 583);
    player1_selected_text.setColor(sf::Color(185,185,185,255));

    player1_selected_text_medium.setFont(font);
    player1_selected_text_medium.setCharacterSize(20);
    player1_selected_text_medium.setPosition(70, 625);
    player1_selected_text_medium.setColor(sf::Color(185,185,185,255));

    player1_selected_text_small.setFont(font);
    player1_selected_text_small.setCharacterSize(15);
    player1_selected_text_small.setPosition(70, 710);
    player1_selected_text_small.setColor(sf::Color(185,185,185,255));

    //Player 2 selected character NAME, OTHER TEXT AND PROJECTILES TEXT
    player2_selected_text.setFont(font);
    player2_selected_text.setCharacterSize(30);
    player2_selected_text.setPosition(1250, 583);
    player2_selected_text.setColor(sf::Color(185,185,185,255));

    player2_selected_text_medium.setFont(font);
    player2_selected_text_medium.setCharacterSize(20);
    player2_selected_text_medium.setPosition(1250, 625);
    player2_selected_text_medium.setColor(sf::Color(185,185,185,255));

    player2_selected_text_small.setFont(font);
    player2_selected_text_small.setCharacterSize(15);
    player2_selected_text_small.setPosition(1250, 710);
    player2_selected_text_small.setColor(sf::Color(185,185,185,255));

}

void Characterwindow::updateGraphics()
{
    clear();
    draw(background);

    //Draw all selectable characters
    for (auto it = std::begin(characters); it != std::end(characters); ++it)
    {
        draw(it->second);
    }

    // Update Opacity of the "Press Enter to Play" text
    if(enterToPlay_opacity_state)
    { if(enterToPlay_opacity>100) { enterToPlay_opacity -= 10; } else { enterToPlay_opacity_state = false; }}
    else
    { if(enterToPlay_opacity<180) { enterToPlay_opacity += 10; } else { enterToPlay_opacity_state = true; }}
    enterToPlay_text.setColor(sf::Color(255, 255, 255, enterToPlay_opacity));

    //Set position of player text based on player's selected id
    player1_text.setPosition(characters[player1_selected_id].getPosition().x + 7, characters[player1_selected_id].getPosition().y);
    player1_text_bg.setPosition(player1_text.getPosition().x + 2, player1_text.getPosition().y + 8);
    player2_text.setPosition(characters[player2_selected_id].getPosition().x + 7, characters[player2_selected_id].getPosition().y);
    player2_text_bg.setPosition(player2_text.getPosition().x + 2, player2_text.getPosition().y + 8);

    //Set texture of selected character based on player's selected character
    player1_selected_character.setTexture(*characters[player1_selected_id].getTexture());
    player2_selected_character.setTexture(*characters[player2_selected_id].getTexture());

    // Print data about selected player 1
    for (int i {0}; i < char_data.size(); ++i)
    {
        if(char_data[i]["id"] == getPlayer1CharacterId())
        {
            // PLAYER 1 SELECTED INFO TEXT

            //Title Text
            player1_selected_text.setString(char_data[i]["name"]);

            // Medium Text
            std::string medium_text {"Health: "};
            int max_health {char_data[i]["max_health"]};
            medium_text.append(std::to_string(max_health));
            int speed {char_data[i]["speed"]};
            medium_text.append("\nSpeed: ");
            medium_text.append(std::to_string(speed));
            medium_text.append("\nProjectiles:");
            player1_selected_text_medium.setString(medium_text);

            // Small Text
            std::string small_text {};
            for ( int i2{0}; i2<char_data[i]["projectiles"].size(); ++i2)
            {
                int projectile_id {char_data[i]["projectiles"].at(i2)};
                for ( int i3{0}; i3<projectile_data.size(); ++i3)
                {
                    if (projectile_data[i3]["id"] == projectile_id)
                    {
                        small_text.append(projectile_data[i3]["name"]);
                        small_text.append(" (");
                        small_text.append(projectile_data[i3]["state"]);
                        small_text.append(")");
                        small_text.append("\nDamage: ");
                        int proj_damage {projectile_data[i3]["damage"]};
                        small_text.append(std::to_string(proj_damage));
                        small_text.append("\nSpeed: ");
                        int proj_speed {projectile_data[i3]["speed"]};
                        small_text.append(std::to_string(proj_speed));
                        small_text.append("\n");
                        small_text.append("\n");
                    }
                }
            }
            player1_selected_text_small.setString(small_text);

            i = char_data.size();

        }
    }
    // Print data about selected player 2
    for (int i {0}; i < char_data.size(); ++i)
    {
        if(char_data[i]["id"] == getPlayer2CharacterId())
        {
            // PLAYER 2 SELECTED INFO TEXT

            //Title Text
            player2_selected_text.setString(char_data[i]["name"]);

            // Medium Text
            std::string medium_text {"Health: "};
            int max_health {char_data[i]["max_health"]};
            medium_text.append(std::to_string(max_health));
            int speed {char_data[i]["speed"]};
            medium_text.append("\nSpeed: ");
            medium_text.append(std::to_string(speed));
            medium_text.append("\nProjectiles:");
            player2_selected_text_medium.setString(medium_text);

            // Small Text
            std::string small_text {};
            for ( int i2{0}; i2<char_data[i]["projectiles"].size(); ++i2)
            {
                int projectile_id {char_data[i]["projectiles"].at(i2)};
                for ( int i3{0}; i3<projectile_data.size(); ++i3)
                {
                    if (projectile_data[i3]["id"] == projectile_id)
                    {
                        small_text.append(projectile_data[i3]["name"]);
                        small_text.append(" (");
                        small_text.append(projectile_data[i3]["state"]);
                        small_text.append(")");
                        small_text.append("\nDamage: ");
                        int proj_damage {projectile_data[i3]["damage"]};
                        small_text.append(std::to_string(proj_damage));
                        small_text.append("\nSpeed: ");
                        int proj_speed {projectile_data[i3]["speed"]};
                        small_text.append(std::to_string(proj_speed));
                        small_text.append("\n");
                        small_text.append("\n");
                    }
                }
            }
            player2_selected_text_small.setString(small_text);

            i = char_data.size();

        }
    }

    //Draw components to screen
    draw(enterToPlay_text);
    draw(player1_text_bg);
    draw(player2_text_bg);
    draw(player1_text);
    draw(player2_text);
    draw(player1_controls);
    draw(player2_controls);
    draw(player1_selected_character);
    draw(player2_selected_character);
    draw(player1_selected_text);
    draw(player1_selected_text_medium);
    draw(player1_selected_text_small);
    draw(player2_selected_text);
    draw(player2_selected_text_medium);
    draw(player2_selected_text_small);
    display();
}

void Characterwindow::movePlayer(Direction direction, bool is_player1 /*= true*/)
{
    //Get distance from image size of a character image
    int x_distance { characters[1].getLocalBounds().width };
    int y_distance { characters[1].getLocalBounds().height };

    if (can_move_player(direction, is_player1))
    {
        switch(direction)
        {
            //Change selected character id for player based on direction
            //...and move player based on width and height of a character sprite
            case Direction::Up:
                //(is_player1 ? sprite_player1 : sprite_player2).move(0, y_distance * -1);
                if (is_player1) { player1_selected_id -= max_row_size; }
                else { player2_selected_id -= max_row_size; }
                break;
            case Direction::Down:
                //(is_player1 ? sprite_player1 : sprite_player2).move(0, y_distance);
                if (is_player1) { player1_selected_id += max_row_size; }
                else { player2_selected_id += max_row_size; }
                break;
            case Direction::Left:
                //(is_player1 ? sprite_player1 : sprite_player2).move(x_distance * -1, 0);
                if (is_player1) { player1_selected_id -= 1; }
                else { player2_selected_id -= 1; }
                break;
            case Direction::Right:
                //(is_player1 ? sprite_player1 : sprite_player2).move(x_distance, 0);
                if (is_player1) { player1_selected_id += 1; }
                else { player2_selected_id += 1; }
                break;
        }
    }
}

int Characterwindow::getPlayer1CharacterId() const
{
    return player1_selected_id;
}

int Characterwindow::getPlayer2CharacterId() const
{
    return player2_selected_id;
}

bool Characterwindow::can_move_player(Direction direction, bool is_player1 /* = true */)
{
    int new_id_p;

    //Get distance from image size of a character image
    switch (direction)
    {
        //Change selected character id for player based on direction
        //...and return if the character id is a valid character id or not
        case Direction::Up:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) - max_row_size;
            break;
        case Direction::Left:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) - 1;
            break;
        case Direction::Down:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) + max_row_size;
            break;
        case Direction::Right:
            new_id_p = (is_player1 ? player1_selected_id : player2_selected_id) + 1;
            break;
    }
    return characters.count(new_id_p) == 1;
}

void Characterwindow::load_characters(std::string const & filename)
{

    int char_id;
    int y {0};
    int x {0};
    for (int i {0}; i < char_data.size(); ++i)
    {
        //Get id of character from file
        char_id = char_data[i]["id"];
        //std::cout << char_id << std::endl;
        //Load the texture based on character's image
        std::string texture_src = char_data[i]["portrait_img"];
        //std::cout << get_texture(texture_src).getSize().x << std::endl;
        //Connect character id with character's portrait sprite
        characters[char_id].setTexture(get_texture(texture_src));

        //Set position of sprite
        characters[char_id].setOrigin(172 / 2, 140 / 2);

        /*
        //Set position of sprite
        characters[char_id].setOrigin(characters[char_id].getLocalBounds().width / 2,
                                      characters[char_id].getLocalBounds().height / 2);
        */

        //Check if you should go to next row
        if (x == max_row_size)
        {
            //Go to next row
            ++y;
            x = 0;
        }
        int row_length = max_row_size * characters[char_id].getLocalBounds().width;
        int x_extra = 420;
        int y_extra = 155;
        characters[char_id].setScale(0.7f, 0.7f);
        characters[char_id].setPosition(x_extra +  (x * 185) + characters[char_id].getOrigin().x,
                                        y_extra +  (characters[char_id].getOrigin().y + (y * 182)) );
        //Go to next column
        ++x;
    }
}

void Characterwindow::load_levels(std::string const & filename)
{
    //Reminder: set origin to middle of image
}

void Characterwindow::load_textures()
{
    //Load character portraits
    std::ifstream char_file {"../resources/data/characters.json"};
    json char_data;
    char_file >> char_data;

    std::string texture_src;
    for (int i {0}; i < char_data.size(); ++i)
    {
        texture_src = char_data[i]["portrait_img"];
        textures[texture_src].loadFromFile("../resources/img/player/" + texture_src);
    }

    //Load level portraits
    std::ifstream level_file {"../resources/data/levels.json"};
    json level_data;
    level_file >> level_data;



    for (int i {0}; i < level_data.size(); ++i)
    {
        texture_src = level_data[i]["portrait_img"];
        textures[texture_src].loadFromFile("../resources/img/level/" + texture_src);
    }

    //Load backgroundimage
    textures["characterscreen_background.png"].loadFromFile("../resources/img/characterscreen_background.png");
}