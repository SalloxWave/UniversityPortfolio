//
// Created by alexanderlinux on 12/10/16.
//

#include "sprite_with_texture.h"

void Sprite_With_Texture::setTextureFromFile(std::string filepath)
{
    //Load texture from filepath
    texture.loadFromFile(filepath);
    //Set texture of current object to that texture
    setTexture(texture);
}
